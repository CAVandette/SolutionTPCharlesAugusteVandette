// But : dans ce dossier, on vient placer les fonctions pour les appeler dans le main et les construirs dans le cpp.
// Auteur : Charles-Auguste Vandette
// Date : 2020--


#pragma once

// La liste des d�clarations des fonctions pour les formes.


// : Ces fonctions, selon la forme, demandent les dimensions de la forme, affichent
// la phrase de pr�sentation de la forme avec les bonnes dimensions et finalement
//appellent la fonction dessinant la forme.Il y aura donc 4 versions de cette
//fonction : traiterRectangle(), traiterCarre(), traiterTriangle(),
//traiterLosange().
int dessinerRectangle(int);
int traiterRectangle(int choixremplissage);

// : Fonction qui dessine un rectangle ou un carr� dont la hauteur, la largeur et le
//mode de remplissage sont pass�s en param�tre.
int dessinerTriangle1(int);
int traiterTriangle(int choixremplissage);

// : Fonction qui dessine un triangle dans la position 1 dont la hauteur et le mode
//de remplissage sont pass�s en param�tre.
int dessinerTriangle2(int);

// : Fonction qui dessine un triangle dans la position 2 dont la hauteur et le mode
//de remplissage sont pass�s en param�tre.
int dessinerTriangle3(int);

// : Fonction qui dessine un triangle dans la position 3 dont la hauteur et le mode
//de remplissage sont pass�s en param�tre.
int dessinerTriangle4(int);

// : Fonction qui dessine un triangle dans la position 4 dont la hauteur et le mode
//de remplissage sont pass�s en param�tre.

int traiterLosange(int choixremplissage);
int dessinerLosange(int);

int traiterCarre(int choixremplissage);
int dessinerCarree(int);

int traiterPara(int choixremplissage);
int dessinerPara(int);

int traiterTriIso(int choixremplissage);
int dessinerTriIso(int);

int genererAlea();
