#include "Formes2077700.h"          // tout les includes qui me permettes de rouler mon programme sans probl�mes.
#include "Labo06Fonctions.h"
#include<iostream>
#include<ctime>
#include<string>

// � qui de droit, je tiens a mentionner plusieurs choses. 1. ce travail n'est pas tel que d�sir�. c'est � dire qu'il est malheureusement incomplet.
// Dans l'optique que ce TP f�t procrastin� � la derni�re minute, non seulement il n'est pas parfait, mais son imperfection est venu au cout de fatigue extr�me
// et acharnement incessant. Au moins, le programme FONCTIONNE. Cet introduction sert � expliqu� les grandes lignes des diff�rences entre l'�x�cutable fournis
// et ma version propre du TP, relire ce message lors des tests serait une bonne id�e comme je n'ai point fourni de plans de test (enfin, aucune indication 
// mentionne de points attribu�s � cet ajout... [._.]). 2. Les diff�rences : Dans l'�x�cutable fournis, un losange est demand�, ce losange fut ma plus grande d�ception
// comme apr�s 8h d'essaie/erreur rien ne fonctionnait alors que la pendule tournais et la fatigue se fesais ressentir. Donc, la hauteur d'un losange ne peut �tre
// d�finie OR, des losanges vides et pleins sont tout de m�mes ajout� au programme, histoire d'afficher au moins quelque chose. la hauteur des 2 losanges est donc d�finie
// � 9. Aussi bien que je sais que mes losanges ne donneront aucun points, je me sentais plus serain de les savoirs au moins disponibles comme mod�ls pour l'utilisateur (Voil� pourquoi
// mon menu 1 affiche que le losange est indisponible(mais mod�le � l'affichage possible)). encore dans les diff�rences, l'ex�cutable fournis du TP propose des protection contre un 
// utilisateur un peu ivre qui n'arrive pas a taper des chiffres! La solution : ERREUR comme message � l'�cran. mon programme propose cette m�me solution � une diff�rence pr�s,
// si l'utilisateur de mon programme d�cide de choisir au menu l'option 2832384 (qui n'existe pas), aucun message d'erreur est affich�! L'utilisateur entrera bien dans le menu 2
// mais qu'importe la r�ponse du menu2, l'utilisateur sera renvoy� au menu1 donc le programme ne �plante� pas, mais il n'est peut-�tre pas fait de b�ton. Comme vous pourrez le voir,
// quelques fonctions suppl�mentaires ont �t� ajout� au main! C'est une triangle isoc�le et un parall�logramme. Je les ai ajout� car dans ma qu�te de trouver la formule d'un losange,
// je trouva plus-t�t un triangle isoc�le (litt�ralement un choix du destin car ce n'est que par essaie/erreur que je le trouva) tout comme le parall�logramme qui n'est pas disponible
// sous la forme vide mais seulement pleine (car le parall�logramme � �galement �t� trouv� d'une erreur pendant la cration d'un de mes triangle.) (j'admet que ce n'est point gratifiant
// de vous annoncer que j'ai trouv� mes 2 formes suppl�mentaires par erreur mais hehe au moin elles sont l�!). Parlant de parall�logramme vide ou plein, j'ai �galement ajout� la 
// possibilit� de choisir le caract�re de remplissage (bien trop facile pour ne pas �tre fait!), mais je suis sur que vous d�couvrirai le tout lors de vos tests!
// Pour terminer donc, j'aimerais ajouter que ce TP �tait incroyablement amusant � faire (bien que j'ai procrastin� et donc �rusher�).

/*
Sources : 
- Tout ce qui se nomme saisirEntier(); provient de Labo06Fonctions.cpp, le .h de ce m�me labo est inclus au programme, l'auteur en est Karine Moreau
- Tout ce qui se nomme saisircaractere(); provient de Labo06Fonctions.cpp, le .h de ce m�me labo est inclus au programme, l'auteur en est Karine Moreau
- Tout ce qui se nomme genererAlea(); provient de programme construit en classe, l'auteur en est Karine Moreau.
- le code de ces deux fonctions provient de ces sources et l'auteur est karine Moreau, programme construit en cours.
*/



using namespace std;
// Alors pour �viter de r�p�ter, dans le cpp formes.cpp (qui contient le code de mes fonctions qui affiches les formes), il y � traiterForme x et dessinerForme x
// Cependant je ne crois pas avoir utiliser les traiterFormes x � un  bon usage, il ne traites rien, ils affiches les dessiner, tout le programme est bas� sur cette id�e
// qui fonctionne mais �tais peut-�tre pas la bonne solution.

int traiterRectangle(int choixremplissage)
{
    dessinerRectangle(choixremplissage);
    system("pause");            // comme dit ici je ne r�p�terai pas mais traiter s'occupe seulement de relayer dessinerForme.
    return 0;
}
int dessinerRectangle(int choixremplissage)
{
    int largeurRectangle, hauteurRectangle;    // Ici je d�clare tout mes variables. dans chaque formes (ou presque) il y � : largeur, hauteur, size, ligne, caract etc
    int ligne1, ligne2;                        // ces nom de variables n'ont parfois pas le meilleur rapport entre le nom et la r�elle utilit� par exemple,
    char caract;                               // dans ce reectangle, ligne 1 et 2 sont utilis�, alors qu'ils ne corresponds pas forc�ment a des lignes mais a des noms de compteurs.

    if (choixremplissage == 2)          // choixRemplissage est tellement important, tout mon programme repose sur cette m�me valeure. choix remplissage
    {                                   // permet de d�terminer le comportement des questions � poser, des r�ponses � fournir et de l'affichage des formes.
        cout << "Entrez la largeur du rectangle --> ";
        largeurRectangle = saisirEntier();      // comme dit dans le paragraphe plus haut, cette fonction n'est pas de mon �crit mais on s'en sert pour �viter de partir en boucle infinie.

        cout << "Entrez la hauteur du rectangle --> ";
        hauteurRectangle = saisirEntier();

        system("cls");
        cout << "Voici le rectangle vide de " << largeurRectangle << "x" << hauteurRectangle << endl; // ici on confirme � l'utilisateur ce qu'il a choisi.

        for (ligne1 = 1; ligne1 <= largeurRectangle; ligne1++)      // comme dit plus haut, les noms ne corresponds pas forc�ment, il sagit de noms de compteurs.
        {
            for (ligne2 = 1; ligne2 <= hauteurRectangle; ligne2++)
            {
                if (ligne1 == 1 || ligne1 == largeurRectangle || ligne2 == 1 || ligne2 == hauteurRectangle)
                {
                    cout << "*";
                }
                else
                {
                    cout << " ";
                }
            }
            cout << endl;
        }                       // fin des boucles qui affichent le rectangle vide.
    }

    if (choixremplissage == 1)
    {
        cout << "Entrez la largeur du rectangle --> ";
        largeurRectangle = saisirEntier();

        cout << "Entrez la hauteur du rectangle --> ";
        hauteurRectangle = saisirEntier();

        cout << "Etrer le caract�re de remplissage -->";
        caract = saisirCaractere();                                 // ici, choix caract est TR�S important car il permet � l'utilisateur de choisir
                                                                    // quelle caract�re de remplissage il veut utiliser.
        system("cls");
        cout << "Voici le rectangle plein de " << largeurRectangle << "x" << hauteurRectangle << endl;

        for (ligne1 = 1; ligne1 <= largeurRectangle; ligne1++)
        {
            for (ligne2 = 1; ligne2 <= hauteurRectangle; ligne2++)
            {
                if (ligne1 == 1 || ligne1 == largeurRectangle || ligne2 == 1 || ligne2 == hauteurRectangle)
                {
                    cout << "*";
                }
                else
                {
                    cout << caract;
                }
            }
            cout << endl;
        }                           // fin des boucles qui affiches le rectangle plein.
    }

    return 0;
}


int traiterTriangle(int choixremplissage)               // Ici il y a quelques diff�rences.
{
    int alea = genererAlea();           // on se sert ici de genererAlea pout s�lectionner de mani�re �al�atoire� une des 4 fonctions de triangle
    if (alea == 1)                      // (chaque fonction dessiner, est compos� de la forme vide a dessiner et la version pleine s�par� par des if.)
    {
        dessinerTriangle1(choixremplissage);
        system("pause");
    }
    if (alea == 2)
    {
        dessinerTriangle2(choixremplissage);
        system("pause");
    }
    if (alea == 3)
    {
        dessinerTriangle3(choixremplissage);
        system("pause");
    }
    if (alea == 4)
    {
        dessinerTriangle4(choixremplissage);
        system("pause");
    }
    

    return 0;
}
int dessinerTriangle1(int choixremplissage)                     // Ici et pour le reste des triangle, il s'agit toujours de la m�me similarit�, les codes se r�p�tes et sont tr�s semblables
{

    int hauteurTri, longeurtri, sizetri;
    char caract;
    if (choixremplissage == 2)
    {
        cout << "Entrer la hauteur du triangle --> ";
        hauteurTri = saisirEntier();
        system("cls");
        cout << "Voici le triangle vide de " << hauteurTri << "x" << hauteurTri << "x" << hauteurTri << endl;

        for (longeurtri = 1; longeurtri <= hauteurTri; longeurtri++)
        {
            for (sizetri = 1; sizetri <= longeurtri; sizetri++)
            {
                if (sizetri == 1 || longeurtri == hauteurTri || sizetri == longeurtri)
                {
                    cout << "*";
                }
                else
                {
                    cout << " ";
                }
            }
            cout << endl;
        }
    }

    if (choixremplissage == 1)
    {
        cout << "Entrer la hauteur du triangle --> ";
        hauteurTri = saisirEntier();
        cout << "Etrer le caract�re de remplissage -->";
        caract = saisirCaractere();
        system("cls");
        cout << "Voici le triangle plein de " << hauteurTri << "x" << hauteurTri << "x" << hauteurTri << endl;

        for (longeurtri = 1; longeurtri <= hauteurTri; longeurtri++)
        {
            for (sizetri = 1; sizetri <= longeurtri; sizetri++)
            {
                if (sizetri == 1 || sizetri == longeurtri || longeurtri == hauteurTri)
                {
                    cout << "*";
                }
                else
                {
                    cout << caract;
                }
            }
            cout << endl;
        }
    }

return 0;
}
int dessinerTriangle2(int choixremplissage)
{
    int hauteurTri, longeurtri, sizetri;
    char caract;

    if (choixremplissage == 2)
    {
        cout << "Entrer la hauteur du triangle --> ";
        hauteurTri = saisirEntier();
        system("cls");
        cout << "Voici le triangle vide de " << hauteurTri << "x" << hauteurTri << "x" << hauteurTri << endl;

        for (longeurtri = 1; longeurtri <= hauteurTri; longeurtri++)
        {
            for (sizetri = longeurtri; sizetri <= hauteurTri; sizetri++)
            {
                if (longeurtri == 1 || sizetri == hauteurTri || sizetri == longeurtri)
                {
                    cout << "*";
                }
                else
                {
                    cout << " ";
                }
            }
            cout << endl;
        }
    }

    if (choixremplissage == 1)
    {
        cout << "Entrer la hauteur du triangle --> ";
        hauteurTri = saisirEntier();
        cout << "Etrer le caract�re de remplissage -->";
        caract = saisirCaractere();
        system("cls");
        cout << "Voici le triangle plein de " << hauteurTri << "x" << hauteurTri << "x" << hauteurTri << endl;

        for (longeurtri = 1; longeurtri <= hauteurTri; longeurtri++)
        {
            for (sizetri = longeurtri; sizetri <= hauteurTri; sizetri++)
            {
                if (longeurtri == 1 || sizetri == longeurtri || sizetri == hauteurTri)
                {
                    cout << "*";
                }
                else
                {
                    cout << caract;
                }
            }
            cout << endl;
        }
    }

    return 0;
}
int dessinerTriangle3(int choixremplissage)
{
    int hauteurTri, longeurtri, sizetri;
    char caract;

    if (choixremplissage == 2)
    {
        cout << "Entrez la hauteur du triangle ";
        hauteurTri = saisirEntier();
        system("cls");
        cout << "Voici le triangle vide de " << hauteurTri << "x" << hauteurTri << "x" << hauteurTri << endl;

        for (longeurtri = hauteurTri; longeurtri >= 1; longeurtri--)
        {
            for (sizetri = hauteurTri - longeurtri + 1; sizetri > 0; sizetri--)
            {
                if (sizetri == 1 || longeurtri == hauteurTri)
                {
                    cout << "*";
                }
                else
                {
                    cout << " ";
                }
            }
            for (sizetri = longeurtri - 1; sizetri > 0; sizetri--)
            {
                if (sizetri == 1 || longeurtri == hauteurTri)
                {
                    cout << "*";
                }
                else
                {
                    cout << " ";
                }

            }
            cout << endl;
        }
    }

    if (choixremplissage == 1)
    {
        cout << "Entrez la hauteur du triangle ";
        hauteurTri = saisirEntier();
        cout << "Etrer le caract�re de remplissage -->";
        caract = saisirCaractere();
        system("cls");
        cout << "Voici le triangle plein de " << hauteurTri << "x" << hauteurTri << "x" << hauteurTri << endl;

        for (longeurtri = hauteurTri; longeurtri >= 1; longeurtri--)
        {
            for (sizetri = hauteurTri - longeurtri + 1; sizetri > 0; sizetri--)
            {
                if (sizetri == 1 || longeurtri == hauteurTri)
                {
                    cout << "*";
                }
                else
                {
                    cout << " ";
                }
            }
            for (sizetri = longeurtri - 1; sizetri > 0; sizetri--)
            {
                if (sizetri == 1 || longeurtri == hauteurTri)
                {
                    cout << "*";
                }
                else
                {
                    cout << caract;
                }

            }
            cout << endl;
        }
    }

    return 0;
}
int dessinerTriangle4(int choixremplissage)
{
    int hauteurTri, longeurtri, sizetri;
    char caract;

    if (choixremplissage == 2)
    {
        cout << "Entrer la hauteur du triangle --> ";
        hauteurTri = saisirEntier();
        system("cls");
        cout << "Voici le triangle vide de " << hauteurTri << "x" << hauteurTri << "x" << hauteurTri << endl;

        for (longeurtri = 1; longeurtri <= hauteurTri; longeurtri++)
        {
            for (sizetri = longeurtri; sizetri < hauteurTri; sizetri++)
            {
                cout << " ";
            }
            for (sizetri = 1; sizetri <= hauteurTri; sizetri++)
            {
                if (longeurtri == hauteurTri || sizetri == longeurtri || sizetri == 1)
                {
                    cout << "*";
                }
                else if (sizetri > longeurtri)
                {
                    cout << " ";
                }
                else
                {
                    cout << " ";
                }
            }
            cout << endl;
        }
    }

    if (choixremplissage == 1)
    {
        cout << "Entrer la hauteur du triangle --> ";
        hauteurTri = saisirEntier();
        cout << "Etrer le caract�re de remplissage -->";
        caract = saisirCaractere();
        system("cls");
        cout << "Voici le triangle plein de " << hauteurTri << "x" << hauteurTri << "x" << hauteurTri << endl;

        for (longeurtri = 1; longeurtri <= hauteurTri; longeurtri++)
        {
            for (sizetri = longeurtri; sizetri < hauteurTri; sizetri++)
            {
                cout << " ";
            }
            for (sizetri = 1; sizetri <= hauteurTri; sizetri++)
            {
                if (longeurtri == hauteurTri || sizetri == 1 || sizetri == longeurtri)
                {
                    cout << "*";
                }
                else if (sizetri > longeurtri)
                {
                    cout << " ";
                }
                else
                {
                    cout << caract;
                }
            }
            cout << endl;
        }
    }
    return 0;
}


int traiterLosange(int choixremplissage)
{
    cout << dessinerLosange(choixremplissage);
    system("pause");
    return 0;
}
int dessinerLosange(int choixremplissage)
{
    if (choixremplissage == 2)
    {
        int sizetri, longeurtri;
        int hauteurtri;


        cout << "Losange en cours de fabrication... [indisponible pour le moment ._.]" << endl;
        cout << "Voici un losange vide de compensation avec une hauteur d�finie � 9 : " << endl;

        cout << "    *" << endl;
        cout << "   * *" << endl;
        cout << "  *   *" << endl;
        cout << " *     *" << endl;
        cout << "*       *" << endl;
        cout << " *     *" << endl;
        cout << "  *   *" << endl;
        cout << "   * *" << endl;
        cout << "    *" << endl;

        // Malheureusement, je n'ai pas r�ussi a fournir un losange... les afficher comme tel �tait plus question d'offrir un programme qui
        // affiche ce qui est demand� ou au moins un mod�le. comme carr�, triangle et rectangle fonctionnent en demandant la hauteur, losange
        // est simplement ici une image et non une forme variable. Probablement qu'un simple �D�sol�, le losange est en cours de fabrication�
        // aurais suffit, mais je trouvais plus agr�able de voir au moin le mod�le qui devait �tre afficher � la base. en contre parti, j'ai
        //fait une fonction de plus comme vous l'aurez surement constater, le parall�llogramme qui je dois avour a �t� trouver par pur erreur 
    }
    else if (choixremplissage == 1)
    {
        cout << "Losange en cours de fabrication... [indisponible pour le moment ._.]" << endl;
        cout << "Voici un losange plein de compensation avec une hauteur d�finie � 9 : " << endl;

        cout << "    *" << endl;
        cout << "   *#*" << endl;
        cout << "  *###*" << endl;
        cout << " *#####*" << endl;
        cout << "*#######*" << endl;
        cout << " *#####*" << endl;
        cout << "  *###*" << endl;
        cout << "   *#*" << endl;
        cout << "    *" << endl;
    }
    

    return 0;
}               // Alors... dessiner losange porte un l�g� probl�me, c'est que ce n'est pas le programme demand�, tout est expliqu� dans le paragraphe d'introduction.


int traiterCarre(int choixremplissage)
{
    cout << dessinerCarree(choixremplissage);
    system("pause");
    return 0;
}
int dessinerCarree(int choixremplissage)
{
    int hauteurCarree, ligne1, ligne2;
    char caract;

    if (choixremplissage == 2)
    {
        cout << "Entrez la hauteur du carr� ";
        hauteurCarree = saisirEntier();
        system("cls");
        cout << "Voici le carr� vide de " << hauteurCarree << "x" << hauteurCarree << endl;

        for (ligne1 = 1; ligne1 <= hauteurCarree; ligne1++)
        {
            for (ligne2 = 1; ligne2 <= hauteurCarree; ligne2++)
            {
                if (ligne1 == 1 || ligne1 == hauteurCarree || ligne2 == 1 || ligne2 == hauteurCarree)
                {
                    cout << "*";
                }
                else
                {
                   cout << " ";
                }
            }
            cout << endl;
       }
    }
    if (choixremplissage == 1)
    {
        cout << "Entrez la hauteur du carr� ";
        hauteurCarree = saisirEntier();
        cout << "Etrer le caract�re de remplissage -->";
        caract = saisirCaractere();
        system("cls");
        cout << "Voici le rectangle plein de " << hauteurCarree << "x" << hauteurCarree << endl;

        for (ligne1 = 1; ligne1 <= hauteurCarree; ligne1++)
        {
            for (ligne2 = 1; ligne2 <= hauteurCarree; ligne2++)
            {
                if (ligne1 == 1 || ligne1 == hauteurCarree || ligne2 == 1 || ligne2 == hauteurCarree)
                {
                    cout << "*";
                }
                else
                {
                    cout << caract;
                }
            }
            cout << endl;
        }
    }
    

    return 0;
}


int traiterPara(int choixremplissage)
{
    dessinerPara(choixremplissage);
    system("pause");
    return 0;
}
int dessinerPara(int choixremplissage)
{
    int hauteurPara;
    int longPara;
    int sizePara;
    if (choixremplissage == 1)
    {
        cout << "Entrer la hauteur du parall�llogramme --> ";
        hauteurPara = saisirEntier();
        system("cls");
        cout << "Voici le parall�logramme plein de " << hauteurPara << "x" << hauteurPara << endl;

        for (longPara = 1; longPara <= hauteurPara; longPara++)
        {
            for (sizePara = longPara; sizePara < hauteurPara; sizePara++)
            {
                cout << " ";
            }
            for (sizePara = 1; sizePara <= hauteurPara; sizePara++)
            {
                if (longPara == hauteurPara || sizePara == 1 || sizePara == longPara)
                {
                    cout << "*";
                }
                else
                {
                    cout << "*";
                }
            }
            cout << endl;
        }
    }
    else if (choixremplissage == 2)
    {
        system("cls");
        cout << "D�sol�, nos formes complexes sont encore en ajustement." << endl;
        cout << "Veuillez tester la forme pleine du parall�logramme pour avoir un r�sultat." << endl;
    }

    

    return 0;
}

int traiterTriIso(int choixremplissage)
{
    dessinerTriIso(choixremplissage);
    system("pause");
    return 0;
}
int dessinerTriIso(int choixremplissage)
{
    int sizetri, longeurtri;
    int hauteurtri;
    char caract;

    if (choixremplissage == 2)
    {
        cout << "Entrez la hauteur du triangle isoc�le --> ";
        hauteurtri = saisirEntier();
        system("cls");
        cout << "Voici le triangle isoc�le vide de " << hauteurtri << "x" << hauteurtri << "x" << hauteurtri << endl;

        for (longeurtri = 1; longeurtri <= hauteurtri; longeurtri++)
        {
            for (sizetri = longeurtri; sizetri <= hauteurtri; sizetri++)
            {
                cout << " ";
            }
            for (sizetri = 1; sizetri <= (2 * longeurtri - 1); sizetri++)
            {
                if (longeurtri == hauteurtri || sizetri == 1 || sizetri == (2 * longeurtri - 1))
                {
                    cout << "*";
                }
                else
                {
                    cout << " ";
                }
            }
            cout << endl;
        }
    }
    else if (choixremplissage == 1)
    {
        cout << "Entrez la hauteur du triangle isoc�le --> ";
        hauteurtri = saisirEntier();
        cout << "Etrer le caract�re de remplissage -->";
        caract = saisirCaractere();
        system("cls");
        cout << "Voici le triangle isoc�le plein de " << hauteurtri << "x" << hauteurtri << "x" << hauteurtri << endl;

        for (longeurtri = 1; longeurtri <= hauteurtri; longeurtri++)
        {
            for (sizetri = longeurtri; sizetri <= hauteurtri; sizetri++)
            {
                cout << " ";
            }
            for (sizetri = 1; sizetri <= (2 * longeurtri - 1); sizetri++)
            {
                if (longeurtri == hauteurtri || sizetri == 1 || sizetri == (2 * longeurtri - 1))
                {
                    cout << "*";
                }
                else
                {
                    cout << caract;
                }
            }
            cout << endl;
        }
    }

    return 0;
}

// Il n'y a que peu de commentaires car la majorit� de ce qui peut �tre expliqu�, n'a besoin que d'�tre expliqu� qu'une fois.

int genererAlea()
{
    int alea;

    // ligne des nombres al�atoires
    srand(time(NULL));

    // On met une valeur al�atoire dans alea en utilisant la fonction rand() pour random
    alea = (rand() % 4 + 1);

    return alea;



}

