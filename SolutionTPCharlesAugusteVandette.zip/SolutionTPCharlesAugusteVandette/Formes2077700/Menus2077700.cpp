#include "Menus2077700.h"
#include "Labo06Fonctions.h"
#include <iostream>
#include <string>



using namespace std;
// affiche le menu 1 dans le main
void afficherMenu1()
{
    cout << "1.     Rectangle" << endl;
    cout << "2.     Triangle" << endl;
    cout << "3.     Carr�" << endl;
    cout << "4.     Losange (malheureusement indisponible ._.)" << endl;
	cout << "5.     Parall�logramme (seulement plein)" << endl;
	cout << "6.     Triangle isoc�le" << endl;
    cout << "7.     Quitter" << endl;
    cout << "Votre choix -->";

}
// Affiche le menu 2 dans le main
void afficherMenu2()
{
	cout << "1.     Forme pleine" << endl;
	cout << "2.     Forme vide" << endl;
	cout << "3.     Retour au menu pr�c�dent" << endl;
	cout << "Votre choix -->";

}
// Valider menu s'occupe de confirmer le menu et de renvoyer la saisie a un programme de correction. (pour �viter les erreurs.)
int validerMenu(int choixMin, int QUITTER)
{

	if (choixMin == 1)
	{
		system("cls");
		afficherMenu1();
	}

	if (choixMin == 2)
	{
		system("cls");
		afficherMenu2();
	}
	return saisirEntier();
}

