// But : dans ce dossier, on vient placer les fonctions pour les appeler dans le main et les construirs dans le cpp.
// Auteur : Charles-Auguste Vandette
// Date : 2020--


#pragma once

// La liste des d�clarations des fonctions qui permettent de g�rer les menus et leurs validations
void afficherMenu1(); // : Fonction qui affiche le menu 1
void afficherMenu2(); // : Fonction qui affiche le menu 2
int validerMenu(int choixMin, int QUITTER); // : Fonction qui lit le choix de l�utilisateur et v�rifie que le choix est bien parmi les
//choix offerts dans le menu, informations pass�es en param�tre.Cette fonction
//retourne le choix valid�.L�utilisateur peut taper n�importe quoi au clavier, le
//programme ne part pas en boucle infinie.