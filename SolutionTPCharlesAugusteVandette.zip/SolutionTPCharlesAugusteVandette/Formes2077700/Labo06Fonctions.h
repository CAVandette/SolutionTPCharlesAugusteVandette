#pragma once


int saisirEntier();
double saisirReel();
char saisirCaractere();
